export const topBarHeight = 45
export const sideNavWidth = 220
export const navbarHeight = 60
export const sidenavCompactWidth = 80
export const containedLayoutWidth = 1200


// content
export const footer_copyrights_text_right = ''
export const footer_copyrights_text_left =  'Copyrights © 2022 All Rights Reserved by ixpress';
export const site_name='iXPRESS';