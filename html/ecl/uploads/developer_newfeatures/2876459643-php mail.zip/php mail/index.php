


<?php

$data = json_decode(file_get_contents('php://input'), true);
$email= $data['user']['email'];
$message= $data['user']['message'];
$subject= $data['user']['subject'];

 
 						
								require_once('mailer/class.phpmailer.php');
								$mail = new PHPMailer();
								$mail->IsSMTP(); 
								$mail->SMTPDebug  = 0;                     
								$mail->SMTPAuth   = true;                  
								$mail->SMTPSecure = "ssl";                 
								$mail->Host       = "mail.aaaaaa.com.bd";      
								$mail->Port       = 465;             
								$mail->AddAddress($email);
											if($file !=''){
								$mail->addStringAttachment(file_get_contents('https://aaaaaa.com.bd/ecl/uploads/mail/'.$file), $file);
	
				}
								$mail->Username="support@aaaaaa.com.bd";  
								$mail->Password="135host";             
								$mail->SetFrom('support@aaaaaa.com.bd','Engineers   Limited');
								$mail->AddReplyTo("support@aaaaaa.com.bd","Engineers   Limited");
								$mail->Subject    = $subject;
								$mail->MsgHTML($message);
								$mail->Send();
								
 
 
 if(!$mail->send()) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
    echo 'Message has been sent';
} 